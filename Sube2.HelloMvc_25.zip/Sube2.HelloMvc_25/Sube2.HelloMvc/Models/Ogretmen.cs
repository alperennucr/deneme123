﻿namespace Sube2.HelloMvc.Models
{
    public class Ogretmen
    {
        public int Ogretmenid { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
    }
}
